import {createContext} from 'react' 

const appContext = createContext();

export default  appContext