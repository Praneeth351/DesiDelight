const cartProducts =[{info:{name:'burger',price:500,_id:89},quantity:1} ,{info:{name:'pizza',price:550,_id:47},quantity:2}];

export default cartProducts

